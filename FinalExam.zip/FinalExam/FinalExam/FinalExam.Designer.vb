﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FinalExam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblntInput = New System.Windows.Forms.Label()
        Me.txtIntInput = New System.Windows.Forms.TextBox()
        Me.btnDouble = New System.Windows.Forms.Button()
        Me.btnHalf = New System.Windows.Forms.Button()
        Me.btnSquare = New System.Windows.Forms.Button()
        Me.btnBinary = New System.Windows.Forms.Button()
        Me.btnHex = New System.Windows.Forms.Button()
        Me.btnJoke = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblntInput
        '
        Me.lblntInput.AutoSize = True
        Me.lblntInput.Location = New System.Drawing.Point(13, 21)
        Me.lblntInput.Name = "lblntInput"
        Me.lblntInput.Size = New System.Drawing.Size(85, 13)
        Me.lblntInput.TabIndex = 0
        Me.lblntInput.Text = "Enter an integer:"
        '
        'txtIntInput
        '
        Me.txtIntInput.Location = New System.Drawing.Point(97, 21)
        Me.txtIntInput.Name = "txtIntInput"
        Me.txtIntInput.Size = New System.Drawing.Size(100, 20)
        Me.txtIntInput.TabIndex = 1
        '
        'btnDouble
        '
        Me.btnDouble.Location = New System.Drawing.Point(16, 97)
        Me.btnDouble.Name = "btnDouble"
        Me.btnDouble.Size = New System.Drawing.Size(181, 23)
        Me.btnDouble.TabIndex = 2
        Me.btnDouble.Text = "Double"
        Me.btnDouble.UseVisualStyleBackColor = True
        '
        'btnHalf
        '
        Me.btnHalf.Location = New System.Drawing.Point(16, 68)
        Me.btnHalf.Name = "btnHalf"
        Me.btnHalf.Size = New System.Drawing.Size(181, 23)
        Me.btnHalf.TabIndex = 3
        Me.btnHalf.Text = "Half"
        Me.btnHalf.UseVisualStyleBackColor = True
        '
        'btnSquare
        '
        Me.btnSquare.Location = New System.Drawing.Point(16, 126)
        Me.btnSquare.Name = "btnSquare"
        Me.btnSquare.Size = New System.Drawing.Size(181, 23)
        Me.btnSquare.TabIndex = 4
        Me.btnSquare.Text = "Square"
        Me.btnSquare.UseVisualStyleBackColor = True
        '
        'btnBinary
        '
        Me.btnBinary.Location = New System.Drawing.Point(16, 155)
        Me.btnBinary.Name = "btnBinary"
        Me.btnBinary.Size = New System.Drawing.Size(181, 23)
        Me.btnBinary.TabIndex = 5
        Me.btnBinary.Text = "Binary"
        Me.btnBinary.UseVisualStyleBackColor = True
        '
        'btnHex
        '
        Me.btnHex.Location = New System.Drawing.Point(16, 184)
        Me.btnHex.Name = "btnHex"
        Me.btnHex.Size = New System.Drawing.Size(181, 23)
        Me.btnHex.TabIndex = 6
        Me.btnHex.Text = "Hexadecimal"
        Me.btnHex.UseVisualStyleBackColor = True
        '
        'btnJoke
        '
        Me.btnJoke.Location = New System.Drawing.Point(16, 214)
        Me.btnJoke.Name = "btnJoke"
        Me.btnJoke.Size = New System.Drawing.Size(181, 23)
        Me.btnJoke.TabIndex = 7
        Me.btnJoke.Text = "Joke of the Day!"
        Me.btnJoke.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnJoke.UseVisualStyleBackColor = True
        '
        'FinalExam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(215, 269)
        Me.Controls.Add(Me.btnJoke)
        Me.Controls.Add(Me.btnHex)
        Me.Controls.Add(Me.btnBinary)
        Me.Controls.Add(Me.btnSquare)
        Me.Controls.Add(Me.btnHalf)
        Me.Controls.Add(Me.btnDouble)
        Me.Controls.Add(Me.txtIntInput)
        Me.Controls.Add(Me.lblntInput)
        Me.Name = "FinalExam"
        Me.Text = "DPDugan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblntInput As Label
    Friend WithEvents txtIntInput As TextBox
    Friend WithEvents btnDouble As Button
    Friend WithEvents btnHalf As Button
    Friend WithEvents btnSquare As Button
    Friend WithEvents btnBinary As Button
    Friend WithEvents btnHex As Button
    Friend WithEvents btnJoke As Button
End Class
