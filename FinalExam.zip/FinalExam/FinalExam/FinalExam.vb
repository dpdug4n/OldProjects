﻿Public Class FinalExam
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblntInput.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtIntInput.TextChanged

    End Sub

    Private Sub btnDouble_Click(sender As Object, e As EventArgs) Handles btnDouble.Click
        'declare variables
        Dim intInput, doubleInput As Integer
        'validate data entered is an integer
        If Not Integer.TryParse(txtIntInput.Text, intInput) Then
            MessageBox.Show("Please Enter an Integer")
            txtIntInput.Text = ""
        Else
            'double the input and display a message
            doubleInput = intInput * 2
            MessageBox.Show("The double of the numbered entered is: " & doubleInput)
            txtIntInput.Text = ""
        End If

    End Sub

    Private Sub btnHalf_Click(sender As Object, e As EventArgs) Handles btnHalf.Click
        'declare variables
        Dim intInput As Integer
        Dim halfInput
        'validate data entered is an integer
        If Not Integer.TryParse(txtIntInput.Text, intInput) Then
            MessageBox.Show("Please Enter a Integer")
            txtIntInput.Text = ""
        Else
            'half the input and display a message
            halfInput = intInput * 0.5
            MessageBox.Show("Half of the numbered entered is: " & halfInput)
            txtIntInput.Text = ""
        End If
    End Sub

    Private Sub btnSquare_Click(sender As Object, e As EventArgs) Handles btnSquare.Click
        'declare variables
        Dim intInput, sqrInput As Integer
        'validate data entered is an integer
        If Not Integer.TryParse(txtIntInput.Text, intInput) Then
            MessageBox.Show("Please Enter a Integer")
            txtIntInput.Text = ""
        Else
            'square the input and display a message
            sqrInput = intInput * intInput
            MessageBox.Show("The square of the numbered entered is: " & sqrInput)
            txtIntInput.Text = ""
        End If
    End Sub

    Private Sub btnBinary_Click(sender As Object, e As EventArgs) Handles btnBinary.Click
        'declare variables
        Dim intInput As Integer
        Dim binaryInput As String
        'validate data entered is an integer
        If Not Integer.TryParse(txtIntInput.Text, intInput) Then
            MessageBox.Show("Please Enter a Integer")
            txtIntInput.Text = ""
        Else
            'convert the input to binary and display a message
            binaryInput = Convert.ToString(intInput, 2).PadLeft(32, "0"c)
            MessageBox.Show("The 32-bit binary value of the numbered entered is: " & binaryInput)
            txtIntInput.Text = ""
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnHex.Click
        'declare variables
        Dim intInput As Integer
        Dim hexInput As String
        'validate data entered is an integer
        If Not Integer.TryParse(txtIntInput.Text, intInput) Then
            MessageBox.Show("Please Enter a Integer")
            txtIntInput.Text = ""
        Else
            'convert the input to hexadecimal and display a message
            hexInput = intInput.ToString("X4")
            MessageBox.Show("The hexadecimal value of the numbered entered is: " & hexInput)
            txtIntInput.Text = ""
        End If
    End Sub

    Private Sub btnJoke_Click(sender As Object, e As EventArgs) Handles btnJoke.Click
        'loads a funny youtube video
        Dim webAddress As String = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        txtIntInput.Text = ""
        Process.Start(webAddress)
    End Sub
End Class
